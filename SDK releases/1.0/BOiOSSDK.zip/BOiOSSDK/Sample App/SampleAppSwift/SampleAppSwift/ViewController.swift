//
//  ViewController.swift
//  SampleAppSwift
//
//  Created by Shefali Shrivastava on 12/03/20.
//  Copyright © 2020 Blotout. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

