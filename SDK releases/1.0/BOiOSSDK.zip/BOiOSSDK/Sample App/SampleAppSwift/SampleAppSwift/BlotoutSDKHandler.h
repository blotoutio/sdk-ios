//
//  BlotoutSDKHandler.h
//  SampleAppSwift
//
//  Created by Shefali Shrivastava on 12/03/20.
//  Copyright © 2020 Blotout. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BlotoutSDKHandler : NSObject

@end

NS_ASSUME_NONNULL_END
