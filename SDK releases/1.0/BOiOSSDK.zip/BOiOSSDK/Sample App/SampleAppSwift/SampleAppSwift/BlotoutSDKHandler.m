//
//  BlotoutSDKHandler.m
//  SampleAppSwift
//
//  Created by Shefali Shrivastava on 12/03/20.
//  Copyright © 2020 Blotout. All rights reserved.
//

#import "BlotoutSDKHandler.h"

@implementation BlotoutSDKHandler

@end
