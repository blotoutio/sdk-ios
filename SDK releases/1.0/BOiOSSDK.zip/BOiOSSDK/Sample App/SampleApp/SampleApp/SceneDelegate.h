//
//  SceneDelegate.h
//  SampleApp
//
//  Created by Shefali Shrivastava on 11/03/20.
//  Copyright © 2020 Blotout. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

