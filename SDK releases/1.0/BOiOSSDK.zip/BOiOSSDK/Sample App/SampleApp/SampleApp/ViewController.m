//
//  ViewController.m
//  SampleApp
//
//  Created by Shefali Shrivastava on 11/03/20.
//  Copyright © 2020 Blotout. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


@end
