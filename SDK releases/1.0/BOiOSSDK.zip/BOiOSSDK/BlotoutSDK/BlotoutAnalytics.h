//
//  BlotoutAnalytics.h
//  BlotoutAnalytics
//
//  Created by Ashish Nigam on 25/07/19.
//  Copyright © 2019 Blotout. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BlotoutAnalytics : NSObject

// Default Value is YES, only set to NO when you want to disable SDK
// Once you disable SDK, SDK won't collect any further information but already collected informtion,
// will be sent to server as per Blotout Contract
@property (nonatomic, readwrite) BOOL isEnabled;
@property (nonatomic, readwrite) BOOL isDataCollectionEnabled;
@property (nonatomic, readwrite) BOOL isNetworkSyncEnabled;

//Individual Module enable or disable control
//System Events, which SDK detect automatically
@property (nonatomic, readwrite) BOOL isSystemEventsEnabled;
//Rentention Events, which SDK detect for retention tracking like DAU, MAU
@property (nonatomic, readwrite) BOOL isRetentionEventsEnabled;
//Funnel Events, which SDK process for funnel analysis
@property (nonatomic, readwrite) BOOL isFunnelEventsEnabled;
//Segments Events, which SDK process for segment analysis
@property (nonatomic, readwrite) BOOL isSegmentEventsEnabled;
//Developer Codified Events, which SDK collects when developer send some events
@property (nonatomic, readwrite) BOOL isDeveloperEventsEnabled;
//Data Sync to server
@property (nonatomic, readwrite) BOOL isPayingUser;


- (nullable instancetype) init __attribute__((unavailable("Must use sharedInstance instead.")));
+ (nullable instancetype)sharedInstance;

-(nonnull NSString*)sdkVersion;

//Fraud Services
-(BOOL)isDeviceCompromised;
-(BOOL)isAppCompromised;
-(BOOL)isNetworkProxied;
-(BOOL)isSimulator;
-(BOOL)isRunningOnVM;
-(BOOL)isEnvironmentSecure;

-(void)setPayingUser:(BOOL)payingUser;

/*
 Blotout provide different staging and production mode for dashboard & clearly keep production analytics separate from staging(Testing mode)
 On the sameline, to provide ease of integration, both the keys can be set here & production mode whether enabled or not can be handled easily with inProductionMode.
 inProductionMode set to false/NO, means test mode is ON & vice-versa
 */
-(void)initializeAnalyticsEngineUsingTest:(NSString*_Nonnull)blotoutTestKey andProduction:(NSString*_Nonnull)blotoutProductionKey inProductionMode:(BOOL)isProdMode withCompletionHandler:(void (^_Nullable)(BOOL isSuccess, NSError * _Nullable error))completionHandler;
-(void)updateAnalyticsEngineTest:(NSString*_Nonnull)blotoutTestKey andProduction:(NSString*_Nonnull)blotoutProductionKey;

-(void)startTimedEvent:(nonnull NSString*)eventName withInformation:(nullable NSDictionary*)startEventInfo;
-(void)endTimedEvent:(nonnull NSString*)eventName withInformation:(nullable NSDictionary*)endEventInfo;

-(void)logEvent:(nonnull NSString*)eventName withInformation:(nullable NSDictionary*)eventInfo;
-(void)logEvent:(nonnull NSString*)eventName withInformation:(nullable NSDictionary*)eventInfo happendAt:(nullable NSDate*)eventTime;

-(void)logUserRetentionEvent:(nonnull NSString*)eventName withInformation:(nullable NSDictionary*)eventInfo;
@end
